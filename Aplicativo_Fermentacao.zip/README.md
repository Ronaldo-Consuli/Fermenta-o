# Monitor de resultados da fermentação

## Publicar no Streamlit Community Cloud

1. Crie um repositório no GitHub.
2. Adicione `app.py` e `requirements.txt` na raiz do repositório, mantendo os nomes.
3. No Streamlit Community Cloud, crie um aplicativo, selecione o repositório e a branch e informe `app.py` como arquivo principal.
4. Após a publicação, carregue um ou mais arquivos do Monitor de Digitação no campo lateral do aplicativo.
5. Clique em **Gerar e baixar HTML** para obter o relatório independente. Ele abre sem internet e oferece impressão / PDF pelo navegador.

Não é necessário colocar a planilha no GitHub. Novas planilhas são carregadas pelo próprio aplicativo.

## Executar no computador

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Regras do painel

- Vinho Bruto: Células Vivas e Bastonetes nas seis dornas identificadas na coluna Equipamento.
- Mosto e Vinho Centrifugado: Acidez e pH, duas tabelas separadas, primeiro Mosto e depois Vinho Centrifugado, com Data / hora do resultado, Material, Característica e Resultado. Equipamento, Local e Tipo de Análise continuam sendo usados internamente para distinguir pontos de coleta.
- A seleção de dia utiliza **Dt. Resultado**. O painel utiliza automaticamente a data mais recente disponível nas análises solicitadas.
- Mostra todos os resultados do dia mais recente em ordem crescente de horário, sem descartar coletas anteriores. Na tabela de dornas, as colunas são Data (sem hora), Dorna, Células vivas (%) e Bastonetes (Bast/ml). Bastonetes usa notação científica, com três algarismos significativos (exemplo: 4,56 × 10⁷). Mosto e Vinho Centrifugado mantêm data e hora.
- Os registros repetidos são preservados. Para as dornas, Células Vivas e Bastonetes são alinhados por horário de resultado, dorna, equipamento, local, tipo de análise e ocorrência. Resultados em horários diferentes aparecem em linhas distintas; a coluna Data continua sem hora, conforme solicitado.
- Ausência de coleta aparece como **Sem resultado**, sem buscar resultados de dias anteriores.
- A barra lateral contém apenas o envio do Excel. A aba SAP Document Export é selecionada automaticamente, ou a primeira aba se ela não existir.
- As células das tabelas são centralizadas. Valores numéricos têm duas casas decimais, inclusive a mantissa de Bastonetes. Acidez é identificada como Acidez (g/L).
- Os valores vêm da planilha; os exemplos da solicitação não são fixados no código. Não há cálculo de médias ou conversão de unidades.
- O leitor espera os cabeçalhos na primeira linha. As colunas necessárias são Material, Equipamento, Característica, Dt. Resultado e Vl. Resultado. Local, Tipo de Análise e Dt. Registro são opcionais.

O arquivo HTML de referência não estava disponível na solicitação; esta versão utiliza um layout próprio em verde e branco. `exemplo_resultados.html` demonstra a exportação com a planilha fornecida.

## Gráficos

Quatro gráficos de linhas abaixo das tabelas: pH e Acidez do Mosto, pH e Acidez do Vinho Centrifugado. Todos os pontos do dia são apresentados por horário com rótulos de duas casas decimais; não são calculadas médias. Os gráficos também acompanham o HTML e funcionam sem internet. A ausência de coleta não é extrapolada. Se houver diferentes pontos de coleta, cada ponto tem uma série identificada.

Nesta revisão, substitua também o requirements.txt no GitHub para incluir matplotlib.

## Vários arquivos

O campo de envio aceita vários arquivos .xlsx ao mesmo tempo. Os resultados são combinados e o painel continua mostrando o dia mais recente encontrado entre as análises solicitadas. Arquivos sem essas análises ou com erro de leitura são identificados na tela; os demais continuam sendo processados. Registros repetidos são preservados, inclusive em arquivos com períodos sobrepostos. A lateral permanece somente com o envio dos arquivos.
